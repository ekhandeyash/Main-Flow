# Q33  Find All Permutations of a String

def permute(s, l, r, result):
    if l == r:
        result.append(''.join(s))
    else:
        for i in range(l, r+1):
            s[l], s[i] = s[i], s[l]  # swap
            permute(s, l+1, r, result)
            s[l], s[i] = s[i], s[l]  # backtrack

string = "abc"
result = []
permute(list(string), 0, len(string)-1, result)
print(result)

#Q34 N-th Fibonacci Number (Dynamic Programming)

def fibonacci(n):
    if n <= 1:
        return n
    dp = [0]*(n+1)
    dp[1] = 1
    for i in range(2, n+1):
        dp[i] = dp[i-1] + dp[i-2]
    return dp[n]

print(fibonacci(10))  # Output: 55

# Q35 Find Duplicates in a List
from collections import Counter

def find_duplicates(lst):
    counter = Counter(lst)
    return [item for item, count in counter.items() if count > 1]

print(find_duplicates([1, 2, 3, 2, 4, 5, 1]))

#Q36 Longest Increasing Subsequence (LIS)

def length_of_LIS(nums):
    n = len(nums)
    dp = [1]*n
    for i in range(n):
        for j in range(i):
            if nums[i] > nums[j]:
                dp[i] = max(dp[i], dp[j]+1)
    return max(dp)

print(length_of_LIS([10, 9, 2, 5, 3, 7, 101, 18]))

#37. Find K Largest Elements

import heapq

def k_largest(nums, k):
    return heapq.nlargest(k, nums)

print(k_largest([1, 23, 12, 9, 30, 2, 50], 3))  # [50, 30, 23]

#38 38. Rotate Matrix (90° Clockwise)

def rotate_matrix(matrix):
    # Step 1: Transpose the matrix
    n = len(matrix)
    for i in range(n):
        for j in range(i, n):  # swap only upper triangle
            matrix[i][j], matrix[j][i] = matrix[j][i], matrix[i][j]
    
    # Step 2: Reverse each row
    for row in matrix:
        row.reverse()

    return matrix

#39 Sudoku Validator

def is_valid_sudoku(board):
    rows = [set() for _ in range(9)]
    cols = [set() for _ in range(9)]
    boxes = [set() for _ in range(9)]  # 3x3 boxes

    for r in range(9):
        for c in range(9):
            val = board[r][c]
            if val == '.':
                continue
            
            # Check row
            if val in rows[r]:
                return False
            rows[r].add(val)
            
            # Check column
            if val in cols[c]:
                return False
            cols[c].add(val)
            
            # Check 3x3 box
            box_index = (r // 3) * 3 + (c // 3)
            if val in boxes[box_index]:
                return False
            boxes[box_index].add(val)
    
    return True



